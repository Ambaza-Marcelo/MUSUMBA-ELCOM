<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('backend/assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/assets/css/font-awesome.min.css') }}">
    <meta charset="utf-8">
    <style type="text/css">
        tr,th,td{
             border: 1px solid black;
             text-align: center;
             width: auto;
        }

    </style>
</head>
<body>
<div class="container">
    <div>
        <div>
            <div>
                <div>
                   <img src="{{ asset('img/eden_logo.png')}}" width="200" height="85">
                </div><br>
                <div>
                    <div style="float: right; border-top-right-radius: 10px solid black;border-top-left-radius: 10px solid black;border-bottom-right-radius: 10px solid black;border-bottom-left-radius: 10px solid black; background-color: rgb(150,150,150);width: 242px;padding: 10px;">
                        <small>
                           &nbsp;&nbsp;@if($data->employe_id) {!! QrCode::size(50)->backgroundColor(255,255,255)->generate('MATRICULE'.$data->employe->matricule_no.', Designed by AMBAZA' ) !!} @endif
                        </small><br>
                        <small>
                            {{ \Carbon\Carbon::parse($data->date_fin)->format('M,Y') }}
                        </small>
                    </div>
                    <br><br><br>
                    <br>
                    <div>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th colspan="4" style="text-align: center;background-color: #027789;">BULLETIN DE PAIE DU {{ \Carbon\Carbon::parse($data->date_debut)->format('d/m/Y') }} AU {{ \Carbon\Carbon::parse($data->date_fin)->format('d/m/Y') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>@lang('messages.NOM ET PRENOM')</th>
                                    <td>@if($data->employe_id){{ $data->employe->firstname }} {{ $data->employe->lastname }} @endif</td>
                                    <th>@lang('messages.MATRICULE')</th>
                                    <td>@if($data->employe_id){{ $data->employe->matricule_no }} @endif</td>
                                </tr>
                                <tr>
                                    <th>@lang('messages.NUMERO DE COMPTE')</th>
                                    <td>@if($data->employe_id){{ $data->employe->numero_compte }} @endif</td>
                                    <th>@lang('messages.CNI')</th>
                                    <td>@if($data->employe_id){{ $data->employe->cni }} @endif</td>
                                </tr>
                                <tr>
                                    <th>@lang('messages.FONCTION')</th>
                                    <td>@if($data->employe_id){{ $data->employe->fonction->name }} @endif</td>
                                    <th>@lang('messages.ANCIENNETE')</th>
                                    @php
                                        $time1 = strftime(strtotime($data->employe->date_debut));
                                        $time2 = strftime(strtotime(\Carbon\Carbon::now()));


                                        $diff = $time2 - $time1;
 
                                        $jours = ($diff / 3600)/24; 
                                    @endphp
                                    <td>@if($jours <= 30)<strong>{{ number_format($jours,0)}}</strong> @lang('messages.jour(s)') @elseif($jours >= 365.25)<strong>{{ number_format($jours/365.25,0)}}</strong> @lang('messages.an(s)') @else {{ number_format(($jours / 30),0) }} @lang('messages.mois') @endif</td>
                                </tr>
                                <tr>
                                    <th>@lang('messages.GENRE')</th>
                                    <td>@if($data->employe->gender === '1') MASCULIN @else FEMININ @endif</td>
                                    <th>@lang('messages.Nbre de personnes a charges')</th>
                                    <td>@if($data->employe->statut_matrimonial === '1') {{ $data->employe->children_number + 1 }} @elseif($data->employe->statut_matrimonial === '2') {{ $data->employe->children_number }} @elseif($data->employe->statut_matrimonial === '3') {{ $data->employe->children_number }} @else 0 @endif</td>
                                </tr>
                                <tr>
                                    <th>@lang('messages.DATE D\'EMBAUCHE')</th>
                                    <td>@if($data->employe_id){{ \Carbon\Carbon::parse($data->employe->date_debut)->format('d/m/Y') }} @endif</td>
                                    <th>@lang('messages.DATE DE FIN')</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table><br>
                        <table class="table table-bordered">
                            <thead>
                                <tr style="text-align: left;background-color: #027789;">
                                    <th>@lang('messages.RUBRIQUES')</th>
                                    <th>@lang('messages.BASE')</th>
                                    <th>@lang('messages.TAUX(PART EMPLOYE)')</th>
                                    <th>@lang('messages.MONTANT(PART EMPLOYE)')</th>
                                    <th>@lang('messages.MONTANT(PART EMPLOYEUR)')</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.SALAIRE DE BASE')</td>
                                    <td>@if($data->employe_id){{ number_format($data->somme_salaire_base,0,',',' ') }} @endif</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.ALLOCATIONS FAMILIALES')</td>
                                    <td></td>
                                    <td></td>
                                    <td>{{ number_format($data->allocation_familiale,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.INDEMNITE DE DEPLACEMENT')</td>
                                    <td>{{ number_format($data->somme_salaire_base,0,',',' ') }}</td>
                                    <td>15%</td>
                                    <td>{{ number_format($data->indemnite_deplacement,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.INDEMNITE DE LOGEMENT')</td>
                                    <td>{{ number_format($data->somme_salaire_base,0,',',' ') }}</td>
                                    <td>60%</td>
                                    <td>{{ number_format($data->indemnite_logement,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.PRIME DE FONCTION')</td>
                                    <td></td>
                                    <td></td>
                                    <td>{{ number_format($data->prime_fonction,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr style="background-color: #027789;">
                                    <td>@lang('messages.SALAIRE BRUT')</td>
                                    <td>{{ number_format($data->somme_salaire_base,0,',',' ') }}</td>
                                    <td></td>
                                    @php
                                        $salaire_brut = ($data->somme_salaire_base + $data->indemnite_deplacement + $data->indemnite_logement + $data->prime_fonction + $data->allocation_familiale);
                                    @endphp
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.INSS')</td>
                                    <td>@if($salaire_brut < 450000){{ number_format($salaire_brut,0,',',' ') }} @else 450 000 @endif</td>
                                    <td>4%</td>
                                    <td>{{ number_format($data->somme_cotisation_inss,0,',',' ') }}</td>
                                    <td>{{ number_format(floor($data->inss_employeur),0,',',' ') }}</td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.ASSURANCE MALADIE')</td>
                                    @php

                                        if ($salaire_brut >= 2000000) {
                                            $base_assurance_maladie = 2000000;
                                        }elseif ($salaire_brut >@lang('messages.= 1000000 && $salaire_brut') < 2000000)                           {
                                            $base_assurance_maladie = 1000000;
                                        }elseif ($salaire_brut >@lang('messages.= 500000 && $salaire_brut') < 1000000) {
                                            $base_assurance_maladie = 500000;
                                        }elseif ($salaire_brut >@lang('messages.= 400000 && $salaire_brut') < 500000) {
                                            $base_assurance_maladie = 400000;
                                        }elseif ($salaire_brut >@lang('messages.= 300000 && $salaire_brut') < 400000) {
                                            $base_assurance_maladie = 300000;
                                        }elseif ($salaire_brut >@lang('messages.= 250000 && $salaire_brut') < 300000) {
                                            $base_assurance_maladie = 250000;
                                        }else{
                                            $base_assurance_maladie = 200000;
                                        }
                                    @endphp
                                    <td>{{ number_format($base_assurance_maladie,0,',',' ') }}</td>
                                    <td></td>
                                    <td>{{ number_format($data->assurance_maladie_employe,0,',',' ') }}</td>
                                    <td>{{ number_format($data->assurance_maladie_employeur,0,',',' ') }}</td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.SOINS MEDICAUX')</td>
                                    <td></td>
                                    <td></td>
                                    <td>{{ number_format($data->soins_medicaux,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    @php

                                        if($salaire_brut < 250000){
                                            $assurance_maladie = 0;
                                        }else{
                                           $assurance_maladie = 6000; 
                                        }

                                        $salaire_brut = ($data->somme_salaire_base + $data->indemnite_deplacement + $data->indemnite_logement + $data->prime_fonction + $data->allocation_familiale);


                                        $base_imposable = $salaire_brut - $data->indemnite_deplacement - $data->indemnite_logement - $data->somme_cotisation_inss - $data->assurance_maladie_employe; 

                                        if ($base_imposable >@lang('messages.= 0 && $base_imposable') <= 150000) {
                                        $somme_impot = 0;
                                        }elseif ($base_imposable > @lang('messages.150000  && $base_imposable') <= 300000) {
                                            $somme_impot = (($base_imposable - 150000) * 20)/100;
                                        }elseif ($base_imposable > 300000) {
                                        $somme_impot = 30000 + (($base_imposable - 300000) * 30)/100;    
                                        }
                                    @endphp
                                    <td>@lang('messages.IMPOT SUR REVENU')</td>
                                    <td>{{ number_format($base_imposable,0,',',' ') }}</td>
                                    <td>@if($base_imposable >= 0 && $base_imposable <= 150000) 0% @elseif($base_imposable > 150000 && $base_imposable <= 300000) 20% @else 30% @endif</td>
                                    <td>{{ number_format($somme_impot,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.RETENUE PRET')</td>
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td></td>
                                    <td>{{ number_format($data->retenue_pret,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.AUTRES RETENUES')</td>
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td></td>
                                    <td>{{ number_format($data->autre_retenue,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr style="background-color: #027789;">
                                    <td>@lang('messages.TOTAL DES DEDUCTIONS')</td>
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td></td>
                                    @php
                                            $total_deductions = $data->somme_cotisation_inss + $data->assurance_maladie_employe + $data->somme_impot + $data->retenue_pret + $data->soins_medicaux + $data->autre_retenue;
                                    @endphp
                                    <td>{{ number_format($total_deductions,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.SALAIRE NET')</td>
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td></td>
                                    <td>{{ number_format(($salaire_brut - $total_deductions),0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>@lang('messages.REMUNERATION BRUTE')</th>
                                    <th>@lang('messages.TOTAL DEDUCTIONS')</th>
                                    <th>@lang('messages.NET A PAYER')</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>@lang('messages.MENSUEL')</td>
                                    <td>{{ number_format($salaire_brut,0,',',' ') }}</td>
                                    <td>{{ number_format($total_deductions,0,',',' ') }}</td>
                                    <td>{{ number_format(($salaire_brut - $total_deductions),0,',',' ') }}</td>
                                </tr>
                            </tbody>
                        </table><br>
                    </div>
                    <div style="float: right;">
                        <a href="{{ route('admin.hr-fiche-paie.print',$data->id) }}" class="btnprn"><img src="{{ asset('img/ISSh.gif') }}" width="60" title="@lang('messages.download_then_print')"></a> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script type="text/javascript">
$(document).ready(function(){
$('.btnprn').printPage();
});
</script>

