
@extends('backend.layouts.master')

@section('title')
@lang('messages.Les Congés pris') - @lang('messages.admin_panel')
@endsection

@section('styles')
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">@lang('messages.Les Congés pris')</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">@lang('messages.dashboard')</a></li>
                    <li><span>@lang('messages.list')</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title float-left">@lang('messages.Les Congés pris')</h4>
                    <p class="float-right mb-2">
                        @if (Auth::guard('admin')->user()->can('hr_conge.create'))
                            <a class="btn btn-primary text-white" href="{{ route('admin.hr-take-conges.create',$company_id) }}">@lang('messages.new')</a>
                        @endif
                    </p>
                    <div class="clearfix"></div>
                    <div class="data-tables">
                        @include('backend.layouts.partials.messages')
                        <table id="dataTable" class="text-center">
                            <thead class="bg-light text-capitalize">
                                <tr>
                                    <th width="5%">#</th>
                                    <th width="10%">@lang('messages.Date')</th>
                                    <th width="10%">@lang('messages.Employé')</th>
                                    <th width="10%">@lang('messages.Type Congé')</th>
                                    <th width="10%">@lang('messages.Date Début')</th>
                                    <th width="10%">@lang('messages.Date Fin')</th>
                                    <th width="10%">@lang('messages.Nbre heures/jours')</th>
                                    <th width="15%">@lang('messages.Action')</th>
                                </tr>
                            </thead>
                            <tbody>
                               @foreach ($take_conges as $take_conge)
                               <tr>
                                    <td>{{ $loop->index+1 }}</td>
                                    <td>{{ $take_conge->created_at }}</td>
                                    <td>@if($take_conge->employe_id){{ $take_conge->employe->firstname }}&nbsp;{{ $take_conge->employe->lastname }} @else {{ $take_conge->stagiaire->firstname }}&nbsp;{{ $take_conge->stagiaire->lastname }} <span class="badge badge-warning">@lang('messages.stagiaire')</span> @endif</td>
                                    <td>@if($take_conge->type_conge_id){{ $take_conge->typeConge->libelle }} @endif</td>
                                    <td>{{ \Carbon\Carbon::parse($take_conge->date_heure_debut)->format('d/m/Y à H:i:s') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($take_conge->date_heure_fin)->format('d/m/Y à H:i:s') }}</td>
                                    <td>@if($take_conge->nbre_heures_conge_pris < 24){{ number_format($take_conge->nbre_heures_conge_pris,0) }} heure(s)@else {{ number_format(($take_conge->nbre_heures_conge_pris / 24),0)}} jour(s) @endif</td>
                                    <td>
                                        @if (Auth::guard('admin')->user()->can('hr_conge.create'))
                                        <a href="{{ route('admin.hr-take-conges.billetSortie', $take_conge->id) }}"><img src="{{ asset('img/ISSh.gif') }}" width="60" title="@lang('messages.download_then_print')"></a>
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('hr_conge.edit'))
                                            <a class="btn btn-success text-white" href="#">@lang('messages.Editer')</a>
                                        @endif

                                        @if (Auth::guard('admin')->user()->can('hr_conge.delete'))
                                            <a class="btn btn-danger text-white" href="{{ route('admin.hr-take-conges.destroy', $take_conge->id) }}"
                                            onclick="event.preventDefault(); if(confirm({{ json_encode(__('messages.confirm_delete_irreversible')) }})) { document.getElementById('delete-form-{{ $take_conge->id }}').submit(); }">
                                                @lang('messages.delete')
                                            </a>

                                            <form id="delete-form-{{ $take_conge->id }}" action="{{ route('admin.hr-take-conges.destroy', $take_conge->id) }}" method="POST" style="display: none;">
                                                @method('DELETE')
                                                @csrf
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                               @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- data table end -->
        
    </div>
</div>
@endsection


@section('scripts')
     <!-- Start datatable js -->
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
     
     <script>
         /*================================
        datatable active
        ==================================*/
        if ($('#dataTable').length) {
            $('#dataTable').DataTable({
                responsive: true
            });
        }

     </script>
@endsection