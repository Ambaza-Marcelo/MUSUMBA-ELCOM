
@extends('backend.layouts.master')

@section('title')
@lang('messages.LE JOURNAL COTISATION INSS') - @lang('messages.admin_panel')
@endsection

@section('styles')
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">@lang('messages.LE JOURNAL COTISATION INSS')</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">@lang('messages.dashboard')</a></li>
                    <li><span>@lang('messages.list')</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>


<!-- page title area end -->
<div class="row">
    <div class="col-md-12">
        <div class="main-content-inner">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title float-left">@lang('messages.LE JOURNAL COTISATION INSS')</h4>
                    <form action="{{ route('admin.hr-journal-cotisations.export-to-excel')}}" method="GET">
                        <p class="float-right mb-2">
                            <button type="submit" value="search" title="@lang('messages.click_export_excel')" class="btn btn-primary">@lang('messages.Exporter En Excel')</button>
                        </p>
                        <p class="float-right mb-2">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="start_date">@lang('messages.Date Debut')</label>
                                    <input type="date" name="start_date" class="form-control" id="start_date">
                                </div>
                                <div class="col-md-4">
                                    <label for="end_date">@lang('messages.Date Fin')</label>
                                    <input type="date" name="end_date" class="form-control" id="end_date">
                                </div>
                            </div>
                        </p>
                    </form>
                    <div class="clearfix"></div>
                    <div class="data-tables">
                        @include('backend.layouts.partials.messages')
                        <table id="dataTable" class="text-center">
                            <thead class="bg-light text-capitalize">
                                <tr>
                                    <th width="5%">#</th>
                                    <th width="10%">@lang('messages.Mois/Année')</th>
                                    <th width="10%">@lang('messages.Employé')</th>
                                    <th width="10%">@lang('messages.Matricule')</th>
                                    <th width="10%">@lang('messages.Salaire de base')</th>
                                    <th width="10%">@lang('messages.Allocation Familiale')</th>
                                    <th width="10%">@lang('messages.Indemnité de logement')</th>
                                    <th width="10%">@lang('messages.Indemnité de déplacement')</th>
                                    <th width="10%">@lang('messages.Prime de fonction')</th>
                                    <th width="10%">@lang('messages.Base Pension')</th>
                                    <th width="10%">@lang('messages.INSS Pension Employé')</th>
                                    <th width="10%">@lang('messages.INSS Pension Employeur')</th>
                                    <th width="10%">@lang('messages.Total INSS Pension')</th>
                                    <th width="10%">@lang('messages.Base INSS Risque')</th>
                                    <th width="10%">@lang('messages.INSS Risque')</th>
                                    <th width="10%">@lang('messages.Total INSS Risque')</th>
                                    <th width="10%">@lang('messages.Net a payer')</th>
                                    <th width="15%">@lang('messages.Action')</th>
                                </tr>
                            </thead>
                            <tbody>
                               @foreach ($journal_cotisations as $journal_cotisation)
                               <tr>
                                    <td>{{ $loop->index+1 }}</td>
                                    <td>{{ \Carbon\Carbon::parse($journal_cotisation->created_at)->format('m/Y') }}</td>
                                    <td>{{ $journal_cotisation->employe->firstname }}&nbsp;{{ $journal_cotisation->employe->lastname }}</td>
                                    <td>{{ $journal_cotisation->employe->matricule_no }}</td>
                                    <td>{{ number_format($journal_cotisation->somme_salaire_base,0,',',' ') }}</td>
                                    <td>{{ number_format($journal_cotisation->allocation_familiale,0,',',' ') }}</td>
                                    <td>{{ number_format($journal_cotisation->indemnite_logement,0,',',' ') }}</td>
                                    <td>{{ number_format($journal_cotisation->indemnite_deplacement,0,',',' ') }}</td>
                                    <td>{{ number_format($journal_cotisation->prime_fonction,0,',',' ') }}</td>
                                    <td></td>
                                    <td>{{ number_format($journal_cotisation->somme_cotisation_inss,0,',',' ') }}</td>
                                    <td>{{ number_format($journal_cotisation->inss_employeur,0,',',' ') }}</td>
                                    @php
                                        $total_inss_pension = $journal_cotisation->inss_employeur + $journal_cotisation->somme_cotisation_inss;
                                    @endphp
                                    <td>{{ number_format($total_inss_pension,0,',',' ') }}</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>{{ number_format($total_inss_pension,0,',',' ') }}</td>
                                    <td></td>
                                </tr>
                               @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</div>
@endsection
@section('scripts')
     <!-- Start datatable js -->
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
     <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
     
     <script>
         /*================================
        datatable active
        ==================================*/
        if ($('#dataTable').length) {
            $('#dataTable').DataTable({
                responsive: true
            });
        }

     </script>
@endsection