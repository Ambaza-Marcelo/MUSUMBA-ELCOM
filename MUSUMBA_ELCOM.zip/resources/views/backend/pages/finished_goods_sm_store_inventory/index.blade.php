
@extends('backend.layouts.master')

@section('title')
@lang('messages.inventory') - Stock des produits finis - @lang('messages.admin_panel')
@endsection

@section('styles')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection

@section('admin-content')

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">@lang('messages.inventory') - Stock des produits finis</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">@lang('messages.dashboard')</a></li>
                    <li><span>@lang('messages.list')</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>

<div class="main-content-inner">
    <div class="row">
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title float-left">@lang('messages.inventory') - Stock des produits finis</h4>
                    <p class="float-right mb-2">
                        <a class="btn btn-primary" href="{{ route('admin.finished-goods-store.index') }}">
                            <i class="fa fa-arrow-left"></i> Retour au stock
                        </a>
                    </p>
                    <div class="clearfix"></div>
                    <div class="data-tables">
                        @include('backend.layouts.partials.messages')
                        <table id="dataTable" class="text-center">
                            <thead class="bg-light text-capitalize">
                                <tr>
                                    <th width="5%">#</th>
                                    <th width="10%">@lang('messages.date')</th>
                                    <th width="10%">@lang('messages.inventory_no')</th>
                                    <th width="10%">@lang('messages.Inventory Signature')</th>
                                    <th width="10%">@lang('messages.Code Store')</th>
                                    <th width="20%">@lang('messages.title')</th>
                                    <th width="10%">@lang('messages.status')</th>
                                    <th width="15%">@lang('messages.description')</th>
                                    <th width="10%">@lang('messages.created_by')</th>
                                    <th width="15%">@lang('messages.Action')</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($inventories as $inventory)
                                <tr>
                                    <td>{{ $loop->index+1 }}</td>
                                    <td>{{ Carbon\Carbon::parse($inventory->date)->format('d/m/Y') }}</td>
                                    <td><a href="{{ route('admin.finished-goods-store-inventory.show', $inventory->inventory_no) }}">{{ $inventory->inventory_no }}</a></td>
                                    <td>{{ $inventory->inventory_signature }}</td>
                                    <td>{{ $inventory->code_store }}</td>
                                    <td>{{ $inventory->title }}</td>
                                    @if($inventory->status == 0)
                                    <td class="alert alert-warning">@lang('messages.En cours')</td>
                                    @elseif($inventory->status == 1)
                                    <td class="alert alert-danger">@lang('messages.Rejeté')</td>
                                    @else
                                    <td class="alert alert-success">@lang('messages.Validé')</td>
                                    @endif
                                    <td>{{ Str::limit($inventory->description, 40) }}</td>
                                    <td>{{ $inventory->created_by }}</td>
                                    <td>
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.edit'))
                                        @if($inventory->status != 2)
                                            <a class="btn btn-success text-white btn-sm" href="{{ route('admin.finished-goods-store-inventory.edit', $inventory->inventory_no) }}">@lang('messages.edit')</a>
                                        @endif
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.delete'))
                                        @if($inventory->status != 2)
                                            <a class="btn btn-danger text-white btn-sm" href="{{ route('admin.finished-goods-store-inventory.destroy', $inventory->inventory_no) }}"
                                            onclick="event.preventDefault(); if(confirm('Êtes-vous sûr de vouloir supprimer cet inventaire ?')) { document.getElementById('delete-form-{{ $inventory->inventory_no }}').submit(); }">
                                                @lang('messages.delete')
                                            </a>
                                            <form id="delete-form-{{ $inventory->inventory_no }}" action="{{ route('admin.finished-goods-store-inventory.destroy', $inventory->inventory_no) }}" method="POST" style="display: none;">
                                                @method('DELETE')
                                                @csrf
                                            </form>
                                        @endif
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.edit'))
                                        @if($inventory->status != 2)
                                            <a class="btn btn-primary text-white btn-sm" href="{{ route('admin.finished-goods-store-inventory.validate', $inventory->inventory_no) }}"
                                            onclick="event.preventDefault(); document.getElementById('validate-form-{{ $inventory->inventory_no }}').submit();">Valider</a>
                                            <form id="validate-form-{{ $inventory->inventory_no }}" action="{{ route('admin.finished-goods-store-inventory.validate', $inventory->inventory_no) }}" method="POST" style="display: none;">
                                                @method('PUT')
                                                @csrf
                                            </form>
                                        @endif
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.edit'))
                                        @if($inventory->status != 2)
                                            <a class="btn btn-warning text-white btn-sm" href="{{ route('admin.finished-goods-store-inventory.reject', $inventory->inventory_no) }}"
                                            onclick="event.preventDefault(); document.getElementById('reject-form-{{ $inventory->inventory_no }}').submit();">Rejeter</a>
                                            <form id="reject-form-{{ $inventory->inventory_no }}" action="{{ route('admin.finished-goods-store-inventory.reject', $inventory->inventory_no) }}" method="POST" style="display: none;">
                                                @method('PUT')
                                                @csrf
                                            </form>
                                        @endif
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.edit'))
                                        @if($inventory->status == 2 || $inventory->status == 1)
                                            <a class="btn btn-secondary text-white btn-sm" href="{{ route('admin.finished-goods-store-inventory.reset', $inventory->inventory_no) }}"
                                            onclick="event.preventDefault(); document.getElementById('reset-form-{{ $inventory->inventory_no }}').submit();">Annuler</a>
                                            <form id="reset-form-{{ $inventory->inventory_no }}" action="{{ route('admin.finished-goods-store-inventory.reset', $inventory->inventory_no) }}" method="POST" style="display: none;">
                                                @method('PUT')
                                                @csrf
                                            </form>
                                        @endif
                                        @endif
                                        @if (Auth::guard('admin')->user()->can('finished_goods_inventory.view'))
                                            <a href="{{ route('admin.finished-goods-store-inventory.generatePdf', $inventory->inventory_no) }}" class="btn btn-info btn-sm" title="PDF"><i class="fa fa-file-pdf-o"></i></a>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
    <script>
        if ($('#dataTable').length) {
            $('#dataTable').DataTable({ responsive: true });
        }
    </script>
@endsection
