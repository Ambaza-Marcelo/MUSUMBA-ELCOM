
@extends('backend.layouts.master')

@section('title')
@lang('messages.Edit Expense category') - @lang('messages.admin_panel')
@endsection

@section('styles')
<style>
    .form-check-label {
        text-transform: capitalize;
    }
</style>
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">@lang('messages.Edit Expense category')</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">@lang('messages.dashboard')</a></li>
                    <li><a href="{{ route('admin.expense-categories.index') }}">@lang('messages.list')</a></li>
                    <li><span>@lang('messages.Edit Expense category')</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">@lang('messages.Edit Expense category')</h4>
                    @include('backend.layouts.partials.messages')
                    
                    <form action="{{ route('admin.expense-categories.update',$expense_category->id) }}" method="POST">
                        @method('PUT')
                        @csrf
                        <div class="row">             
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name" class="col-form-label">@lang('messages.description:')</label>
                                        <input type="text" name="name" class="form-control" id="name" value="{{ $expense_category->name }}">
                                    </div>
                                </div>
                            </div>
                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">@lang('messages.update')</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->
        
    </div>
</div>
@endsection